#README LaTeX template
1. Contenuto del frontespizio modificabile grazie all'aggiunta del file ".res/config/docInfo.tex" dove si dovranno aggiungere le informazioni riguardanti il documento;
2. il resto rimane come al solito: sezioni in res/sections da includere nel file "listOfSections.tex" e via dicendo
